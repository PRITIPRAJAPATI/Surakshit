
# ***Surakshit : A Womens Safety Application***
> **Be safe**
> 
> Women Safety Application is user friendly application built in Android Studio, it is simple to implement, easy to understand.

Price 1500 Rupees Only!

Report available 500 Rupees!

Contact Here
[WhatsApp](https://api.whatsapp.com/send/?phone=919029979652&text&type=phone_number&app_absent=0) 			[Telegram](https://t.me/Priti_Prajapati4)

## Features

  -   Easy to implement
-   Easy to understand
-   Shake detector
-   Siren sound
-   Call to registered mobile
-   Shake device to send SOS to registered mobile and play siren
-   Sends Last Known Location to registered mobile
-   Now we can add multiple contacts to send SOS

![Surakshit](https://github.com/PRITIPRAJAPATI/Surakshit/assets/82827088/66a65cb2-cccd-4b6b-928d-a50f62c3a4f1)
    
#### Prerequisites :

  -   Android Studio
-   Basic knowledge about Firebase Authentication and Realtime database.

## Build and Run Application
Surakshit - A Women Safety Application requires Android Oreo or newer version to run.

Follow this steps to get Working Project!

    Clone this repository or download file
    Extract zip if downloaded code
    Open project in Android Studio
    Wait while Android Studio Download gradle or required files
    Hit Run Button !
   


