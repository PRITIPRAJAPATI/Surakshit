package com.darkness.Surakshit;

public interface MyOnClickListener {
    void onItemClicked(int position);
}
